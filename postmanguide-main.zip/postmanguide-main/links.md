# Полезные ссылки по Postman

## 📥 Установка Postman
- [Официальная страница загрузки](https://www.postman.com/downloads/)

## 🏝 Песочницы
- [Публичное API SpaseX](https://docs.spacexdata.com/)
- [Публичное API Swagger PetStore](https://petstore.swagger.io/#/pet/addPet)
- [WebSocket песочница Gosandy](https://app.gosandy.io/)

## 📖 Полезные статьи
- [Документация Chai.js](https://www.chaijs.com)
